package dev.codenmore.tilegame;


public class Launcher {

	public static void main(String[] args){
		new Game("Tile Game!", 400, 400);
	}
	
}
