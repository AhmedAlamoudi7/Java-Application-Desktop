package dev.codenmore.tilegame;

import dev.codenmore.tilegame.display.Display;

public class Launcher {

	public static void main(String[] args){
		new Display("Title!", 300, 300);
	}
	
}
