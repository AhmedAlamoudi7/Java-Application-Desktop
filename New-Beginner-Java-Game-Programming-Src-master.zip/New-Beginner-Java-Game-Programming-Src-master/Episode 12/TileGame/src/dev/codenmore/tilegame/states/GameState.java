package dev.codenmore.tilegame.states;

import java.awt.Graphics;


public class GameState extends State {

	public GameState(){
		
	}
	
	@Override
	public void tick() {
		
	}

	@Override
	public void render(Graphics g) {
		
	}

}
